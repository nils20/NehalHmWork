package Veltech;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Hello world!
 *
 */
public class Utility extends DriverManger
{
   public static void clickOnElement(WebElement element)
   {
       element.click();
   }
    public static String getText(WebElement element){
        String txt=element.getText();
        return txt;

    }
}
