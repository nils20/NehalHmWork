package Veltech;

import org.openqa.jetty.html.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 24/11/2016.
 */
public class CityPage extends DriverManger {


    @FindBy(css = "i.icons.glyph")
    private WebElement _servicelocation;

@FindBy (css = "p.contactheader")
private WebElement _actualResult;


    public void serviceLocation(){

        Utility.clickOnElement(_servicelocation);
        java.util.List<WebElement> allLinkElement=driver.findElements(By.xpath("//div[@id='contactbox']/div/div/*"));
        java.util.List<WebElement> allLinkElement1=driver.findElements(By.xpath("//div[@id='contactbox']/div/div/ul/*"));

        int count = allLinkElement.size();
       int count1=allLinkElement1.size();

       System.out.println(" Total Number of Office Are :" );//+count);
        System.out.println(" ------------------------  ");
        for (int i = 0; i < allLinkElement.size(); i++)

        {

            System.out.print(" "+allLinkElement.get(i).getText());
        }

        System.out.println("\n"+"Total Number of City Are :" +count1+" ");
        System.out.println(" ---------  ");

        for (int j = 0; j < allLinkElement1.size(); j++) {

            System.out.println(" "+allLinkElement1.get(j).getText());

        }

        Assert.assertEquals("Contact our other offices",Utility.getText(_actualResult));
        System.out.println("Test pass");
    }



}
