package Veltech;

import com.sun.jna.Platform;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

import static org.apache.tools.ant.types.resources.MultiRootFileSet.SetType.file;

/**
 * Created by User on 24/11/2016.
 */
public class DriverManger {

    protected static WebDriver driver;




    public DriverManger(){
        PageFactory.initElements(driver,this);
    }



    public static void openBrowser() {

       // String browser="";  // firefox
     //  String browser = "chrome";// if we do name chrome than takechrome
         String browser="IE";  // IE (InternetExplorer)

        if (browser.equalsIgnoreCase("ie"))
        {
            System.setProperty("webdriver.ie.driver", "src/test/Resource/Browser Drivre/IEDriverServer 32.exe");
            driver = new InternetExplorerDriver();
        } else if (browser.equalsIgnoreCase("chrome"))
        {
            System.setProperty("webdriver.chrome.driver", "src/test/Resource/Browser Drivre/chromedriver.exe");
            //  C:\Users\User\IdeaProjects\Veltech_Service\src\test\Resource\Browser Drivre\chromedriver.exe
            driver = new ChromeDriver();

        } else
            {
            driver = new FirefoxDriver();
        }

         //   driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
       driver.manage().window().setSize(new Dimension(800,600) );
        // driver.manage().window().maximize();
        driver.get("https://www.valtech.co.uk/");
        driver.findElement(By.tagName("body")).sendKeys(Keys.F11);

    }
    public static void closeBrowser(){
        driver.quit();
    }
}
