package Veltech;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

/**
 * Unit test for simple Utility.
 */
public class Testsuit
    extends DriverManger{
@BeforeTest
    public static void open(){
    DriverManger.openBrowser();

}
@AfterTest
    public static void close(){
    DriverManger.closeBrowser();
}

@org.testng.annotations.Test
    public static void service_Loction(){

    CityPage cityPage=new CityPage();

    cityPage.serviceLocation();


}

}
