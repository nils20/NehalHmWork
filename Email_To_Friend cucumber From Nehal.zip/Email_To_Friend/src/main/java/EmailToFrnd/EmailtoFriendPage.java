package EmailToFrnd;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by User on 01/12/2016.
 */
public class EmailtoFriendPage extends DriverManager {



    @FindBy(xpath = "//input[@id='FriendEmail']")
    private WebElement friendEmail;

    @FindBy(xpath = "//textarea[@id='PersonalMessage']")
    private WebElement _personalMessageBox;

    @FindBy(xpath = "//form/div[2]/input")
    private WebElement _clickToSendEmailKey;

    @FindBy(xpath = "//div[3]/div/div/div/div[2]/div[2]")
    private WebElement _actulResult_SentMailMessage;


    @FindBy(xpath= "//div[2]/ul/li/a")
    private WebElement _computerHeader;


    @FindBy(linkText = "Desktops")
    private WebElement _destopHeader;

    @FindBy(xpath = "//div[3]/div/div[2]/h2/a")
    private WebElement _lenova600;

    @FindBy(xpath = "//div[3]/input")
    private WebElement _clickonEmail;

    public void productOfDesktops() throws InterruptedException {

        Utility.explisityWait(_computerHeader,1000);
        Utility.cliclOnElement(_computerHeader);
        Utility.explisityWait(_destopHeader,1000);
        Utility.cliclOnElement(_destopHeader);


    }

    public void clickOnEmailToFriedn()
    {
        Utility.explisityWait(_lenova600,1000);
        Utility.cliclOnElement(_lenova600);
        Utility.explisityWait(_clickonEmail,1000);
        Utility.cliclOnElement(_clickonEmail);


    }


    public void emailToFriend() throws InterruptedException {

        String friednid = "veeru" + Utility.randomDate() + "@hmail1.com";

        Utility.typeText(friendEmail,friednid);
        //  Utility.typeText(_friendEmail,"tt.rtr@yahoo.co");

        Utility.typeText(_personalMessageBox,"You can check product ,It's looks Good ");

        Utility.cliclOnElement(_clickToSendEmailKey);

      /*  Assert.assertEquals("Your message has been sent.",Utility.getText(_actulResult_SentMailMessage));

        System.out.println("Message Sent ");*/
    }

        public void asserforEmailFriend(){

                   Assert.assertEquals("Your message has been sent.",Utility.getText(_actulResult_SentMailMessage));

        System.out.println("Message Sent ");

        }
}
