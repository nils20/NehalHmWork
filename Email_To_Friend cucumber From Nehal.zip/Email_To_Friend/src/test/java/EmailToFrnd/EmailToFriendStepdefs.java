package EmailToFrnd;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Assert;

/**
 * Unit test for simple Utility.
 */
public class EmailToFriendStepdefs
    extends DriverManager
{

    @Given("^I am already login as member and I am on product page$")
    public void i_am_already_login_as_member_and_I_am_on_product_page() throws InterruptedException {

        openBrowser();
        RegisterPageNopCommerce registerPageNopCommerce=new RegisterPageNopCommerce();
        registerPageNopCommerce.registerForm();
    }

    @When("^I am able to refer friend by click on link at product page$")
    public void i_am_able_to_refer_friend_by_click_on_link_at_product_page() throws InterruptedException

    {
        EmailtoFriendPage emailtoFriendPage = new EmailtoFriendPage();
        emailtoFriendPage.productOfDesktops();
        emailtoFriendPage.clickOnEmailToFriedn();

    }

    @And("^I fill all valid detail on email a friend page$")
    public void i_fill_all_valid_detail_on_email_a_friend_page() throws InterruptedException {
        EmailtoFriendPage emailtoFriendPage = new EmailtoFriendPage();

        emailtoFriendPage.emailToFriend();

    }

    @Then("^I should able to send email to Friend from  email to friend page$")
    public void i_should_able_to_send_email_to_Friend_from_email_to_friend_page()
    {
        EmailtoFriendPage emailtoFriendPage = new EmailtoFriendPage();
        emailtoFriendPage.asserforEmailFriend();
        closeBrowser();
    }

}
