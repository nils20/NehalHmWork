package EmailToFrnd;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by User on 01/12/2016.
 */

@RunWith(Cucumber.class)
@CucumberOptions(features ="src/test/Resource/Feature/emailToFriend.feature" )
public class RunTest extends DriverManager {
}
