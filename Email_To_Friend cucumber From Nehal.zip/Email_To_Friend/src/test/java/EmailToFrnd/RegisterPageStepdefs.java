package EmailToFrnd;

/**
 * Created by User on 01/12/2016.
 */
public class RegisterPageStepdefs {
}
