package NopCommec;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 * Unit test for simple DriverManger.
 */
public class TestSuit extends DriverManger{





    @BeforeTest
    public static void open(){
    DriverManger.openBrowser();
}

@AfterTest
    public static void close(){
    DriverManger.closeBrowser();
}



@org.testng.annotations.Test
public void useronRegisterPage() throws InterruptedException {
    RegisterPage registerPage = new RegisterPage();
    registerPage.registerForm();

}

@Test
public void userCompleteRegestration() throws InterruptedException {
    RegisterPage registerPage = new RegisterPage();

    RegisterCompletePage registerResultpage=new RegisterCompletePage();
    registerPage.registerForm();
    registerResultpage.continueFor();
}

@Test
public void userAddProductFrom_DesktopPage() throws InterruptedException
{
    MainPage mainPage=new MainPage();
    DesktopsPage destopPage=new DesktopsPage();

    mainPage.productOfDesktops();
    destopPage.elementFrom_Desktop();

}

@Test

public void userAddProductFrom_ElectronicsPage() throws InterruptedException {
    MainPage mainPage=new MainPage();
    ElectronicsPage electronicsPage=new ElectronicsPage();
       mainPage.productOfElectronics();
    electronicsPage.elementFromElectronicPage();
}

@Test
public void userClickonShoppingCart() throws InterruptedException {

    MainPage mainPage=new MainPage();
    ElectronicsPage electronicsPage=new ElectronicsPage();
    Shopping_CartPage shopping_cartPage=new Shopping_CartPage();
    mainPage.productOfElectronics();
    electronicsPage.elementFromElectronicPage();
    mainPage.shopping_cartWindow();


}
/*
@Test
public void usercheckandClickOnChekoutButton() throws InterruptedException {
    MainPage mainPage=new MainPage();
    ElectronicsPage electronicsPage=new ElectronicsPage();
    Shopping_CartPage shopping_cartPage=new Shopping_CartPage();
    mainPage.productOfElectronics();                                 // method for check checkout is working
    electronicsPage.elementFromElectronicPage();
    mainPage.shopping_cartWindow();
    shopping_cartPage.user_on_Checkout();


}*/
@Test
public void userOnShopping_CartPage() throws InterruptedException {

    RegisterPage registerPage = new RegisterPage();
    RegisterCompletePage registerResultpage=new RegisterCompletePage();
    MainPage mainPage=new MainPage();
    DesktopsPage destopPage=new DesktopsPage();
    ElectronicsPage electronicsPage=new ElectronicsPage();
    Shopping_CartPage shopping_cartPage=new Shopping_CartPage();

    registerPage.registerForm();
    registerResultpage.continueFor();
    mainPage.productOfDesktops();
    destopPage.elementFrom_Desktop();
    mainPage.productOfElectronics();
    electronicsPage.elementFromElectronicPage();
    mainPage.shopping_cartWindow();
    shopping_cartPage.user_on_Checkout();
}

@Test
public void emailSendToFriend() throws InterruptedException {
    RegisterPage registerPage = new RegisterPage();
    RegisterCompletePage registerResultpage=new RegisterCompletePage();
    MainPage mainPage=new MainPage();
    DesktopsPage destopPage=new DesktopsPage();
    EmailFriend emailFriend =new EmailFriend();

    registerPage.registerForm();
    registerResultpage.continueFor();
    mainPage.productOfDesktops();
    destopPage.clickOnEmailToFriedn();
    emailFriend.emailToFriend();



}



@org.testng.annotations.Test

       public  void userBuyEndToEnd() throws InterruptedException {

    RegisterPage registerPage = new RegisterPage();
    RegisterCompletePage registerResultpage=new RegisterCompletePage();
    MainPage mainPage=new MainPage();
    DesktopsPage destopPage=new DesktopsPage();
    ElectronicsPage electronicsPage=new ElectronicsPage();
    Shopping_CartPage shopping_cartPage=new Shopping_CartPage();
    BillingPage_1 billingPage_1=new BillingPage_1();

          registerPage.registerForm();
        registerResultpage.continueFor();
         mainPage.productOfDesktops();
         destopPage.elementFrom_Desktop();
         mainPage.productOfElectronics();
         electronicsPage.elementFromElectronicPage();
         mainPage.shopping_cartWindow();
       shopping_cartPage.user_on_Checkout();
         billingPage_1.billingPage();


        }
/*@org.testng.annotations.Test
    private void registerForm() {

        registerForm();
    }*/
}


