package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 29/11/2016.
 */
public class EmailFriend extends DesktopsPage{


    @FindBy(xpath = "//input[@id='FriendEmail']")
    private WebElement friendEmail;

    @FindBy(xpath = "//textarea[@id='PersonalMessage']")
    private WebElement _personalMessageBox;

    @FindBy(xpath = "//form/div[2]/input")
    private WebElement _clickToSendEmailKey;

    @FindBy(xpath = "//div[3]/div/div/div/div[2]/div[2]")
    private WebElement _actulResult_SentMailMessage;



    public void emailToFriend() throws InterruptedException {

        String friednid = "veeru" + Utility.randomDate() + "@hmail1.com";

        Utility.typeText(friendEmail,friednid);
      //  Utility.typeText(_friendEmail,"tt.rtr@yahoo.co");

        Utility.typeText(_personalMessageBox,"You can check product ,It's looks Good ");

        Utility.cliclOnElement(_clickToSendEmailKey);

        Assert.assertEquals("Your message has been sent.",Utility.getText(_actulResult_SentMailMessage));

        System.out.println("Message Sent ");
    }
}
