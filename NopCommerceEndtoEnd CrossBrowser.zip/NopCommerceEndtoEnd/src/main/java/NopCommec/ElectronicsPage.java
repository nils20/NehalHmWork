package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class ElectronicsPage extends DriverManger {


    @FindBy(css ="h2.product-title > a")
    private WebElement _htcOneM8_A5;

    @FindBy(xpath = "//div/input[2]")
    private WebElement _addTocart;

    @FindBy(css = "p.content")
    private WebElement actualResult_productAdd;


    public void elementFromElectronicPage () throws InterruptedException {

        Utility.cliclOnElement(_htcOneM8_A5);
        Utility.cliclOnElement(_addTocart);

        Assert.assertEquals("The product has been added to your shopping cart",Utility.getText(actualResult_productAdd));
        System.out.println("The product has been added to your shopping shopping_cartWindow");

    }



}
