package NopCommec;

import org.apache.http.util.Asserts;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class RegisterPage extends DriverManger{

//Utility utility=new Utility();

    @FindBy(css = "a.ico-register")
    private WebElement _register;

    @FindBy(css = "#gender-male")
    private WebElement _genderMale;

    @FindBy(id="gender-female")
    private WebElement _genderFemale;

    @FindBy(xpath = "//div[2]/input")
    private WebElement _firstName;

    @FindBy(xpath="//div[3]/input")
    private WebElement _lastName;

    @FindBy(xpath = "//div[4]/select")
    private WebElement _birthDay;

    @FindBy(xpath = "//select[2]")
    private WebElement _birthMonth;

    @FindBy(xpath= "//select[3]")
    private WebElement _birthYear;

    @FindBy(xpath="//div[5]/input")
    private WebElement _email;

    @FindBy(xpath="//div[2]/div[2]/div/input")
    private WebElement _Company;

    @FindBy(css="#Password")
    private WebElement _passWord;

    @FindBy(css="#ConfirmPassword")
    private WebElement _confirmPassword;

    @FindBy(xpath = "//form/div/div[2]/div[5]/input")
    private WebElement _registerButton;

    @FindBy(className="result")
    private WebElement _actulResult;


public  void registerForm() throws InterruptedException {
    Utility.cliclOnElement(_register);
    Utility.cliclOnElement(_genderMale);
    Utility.typeText(_firstName,"ram");
    Utility.typeText(_lastName,"Rathod");
    Utility.scrollBy(_birthDay,1);
    Utility.scrollBy(_birthMonth,3);
    //Utility.scrollbyVisibleText(_birthMonth,"March");
   // Utility.scrollbyVisibleText(_birthYear,1990);
    Utility.scrollBy(_birthYear,25);
    String email ="ne102"+Utility.randomDate()+"@gmail.com";// virtual email ganareter unique
    Utility.typeText(_email,email);
    System.out.println(email);
    Utility.typeText(_Company,"Actt");
    Utility.typeText(_passWord,"aB12345");
    Utility.typeText(_confirmPassword,"aB12345");
    Utility.cliclOnElement(_registerButton);


    Assert.assertEquals("Your registration completed",Utility.getText(_actulResult));

    System.out.println("Test pass for Register  page");



}





}
