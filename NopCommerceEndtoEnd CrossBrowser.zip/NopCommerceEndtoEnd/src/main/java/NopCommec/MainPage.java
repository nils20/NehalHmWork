package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class MainPage extends DriverManger{


    @FindBy(name = "Register")
    private WebElement _register;

    @FindBy(xpath= "//div[2]/ul/li/a")
    private WebElement _computerHeader;


    @FindBy(linkText = "Desktops")
    private WebElement _destopHeader;

    @FindBy(xpath = "//li[3]/strong")
    private WebElement _actualResult_userOnDesktopPage;

    @FindBy(xpath = "//div[2]/ul/li[2]/a")
    private WebElement _electronicsHeader;

    @FindBy(linkText = "Cell phones")
    private WebElement _cellPhone;

    @FindBy(xpath = "//li[3]/span/a/span")
    private WebElement _actualResult_useroncellphonepage;

    @FindBy(xpath = "//li[4]/a/span")
    private WebElement _shoppingcart;

    @FindBy(xpath = "//input[@value='Go to cart']")
    private WebElement goto_cartButton;

    @FindBy(css = "span.close")
    private WebElement _closebox;

    @FindBy(linkText = "Shopping cart")
private WebElement _actualCart;



    public void productOfDesktops() throws InterruptedException {

        Utility.cliclOnElement(_computerHeader);

        Utility.cliclOnElement(_destopHeader);

        Assert.assertEquals("Desktops",Utility.getText(_actualResult_userOnDesktopPage));
        System.out.println("User on the Desktops page");
    }
    public void productOfElectronics() {
        Utility.cliclOnElement(_electronicsHeader);
        Utility.cliclOnElement(_cellPhone);

    }

    public void shopping_cartWindow() throws InterruptedException {
        Utility.cliclOnElement(_closebox);
       Utility.mouseHoveraction(_shoppingcart);
        System.out.println("userclick");

        Utility.explisityWait(goto_cartButton,4000);
        Utility.cliclOnElement(goto_cartButton);
        System.out.println("product Add");

       Assert.assertEquals("Shopping cart",Utility.getText(_actualCart));
       System.out.println("user click on shopping cart page");

    }


    }

