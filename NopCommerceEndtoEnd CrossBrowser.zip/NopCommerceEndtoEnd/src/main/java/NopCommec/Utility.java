package NopCommec;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seleniumhq.jetty9.server.HttpChannelState;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * Created by User on 22/11/2016.
 */
public class Utility extends DriverManger {


    public static void cliclOnElement(WebElement element){
        element.click();
    }

    public static void typeText(WebElement element,String text){
        element.sendKeys(text);
    }

    public static String randomDate()        /*for email generat create date format */
    {
        DateFormat format =new SimpleDateFormat("ddMMMyyHHmmss");
        return format.format(new Date());
    }

    public static void scrollBy(WebElement element,int a)
    {
    new Select(element).selectByIndex(a);
    }

    public static void scrollbyVisibleText(WebElement element,String text)
    {
        new Select(element).selectByVisibleText(text);
    }

    public static void explisityWait(WebElement element,int timeout){      // explisit wait


        WebDriverWait wait=new WebDriverWait(driver,timeout);
       wait.until(ExpectedConditions.visibilityOf(element));

    }

    public static void waitUntilElementClickable (WebElement element, int timeout)                             // WAIT  READY  AND CLICK
    {
        //element=null;
        WebDriverWait expwait=new WebDriverWait(driver,timeout);
        element=expwait.until(ExpectedConditions.elementToBeClickable(element));
     //   element.click();

    }

    public static  WebElement  clickOnVisible(WebElement element,int timeout)                    //  WAIT VISIBLE AND CLICK METHOD
    {
      //  element=null;
        WebDriverWait wait=new WebDriverWait(driver,timeout);
        element=  wait.until(ExpectedConditions.visibilityOfElementLocated((By) element));
        return element;

    }


    public static int randomNum()                                               // RANDOM NUMBER GENERATE METHOD
    {

        Random randumnum= new Random();
        int randumnum1 =0 ;                  //INITLISE VALUE IS 0
        randumnum1=  randumnum.nextInt(9999999);   // MAX RANGE IS 9999999 ,SO NUM IS BETWEEN 0 TO 999999
        return randumnum1;

    }

    public static String getText(WebElement element)
    {
     String txt=element.getText();
        return txt;
    }
    public static void mouseHoveraction(WebElement element)
    {
        WebElement abc = element;
        Actions actions=new Actions(driver) ;
        actions.moveToElement(abc).perform();

        }



    }











