package NopCommec;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

/**
 * Hello world!
 *
 */
public class DriverManger
{

    protected static WebDriver driver;

    public DriverManger(){
        PageFactory.initElements(driver,this);
    }

    public static void openBrowser()
    {

       // String browser="";
       String browser="chrome";
      //String browser="IE";

        if (browser.equalsIgnoreCase("chrome")){


            System.setProperty("webdriver.chrome.driver","C:\\Users\\User\\IdeaProjects\\NopCommerceEndtoEnd\\src\\test\\Resource\\BrowserDriver\\chromedriver.exe");
            driver=new ChromeDriver();
        } else if(browser.equalsIgnoreCase("ie")){


            System.setProperty("webdriver.ie.driver","src\\test\\Resource\\BrowserDriver\\IEDriverServer 32.exe");
            driver=new InternetExplorerDriver();
        }
        else
        {
            driver=new FirefoxDriver();
        }

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get("http://demo.nopcommerce.com");

    }

    public static void closeBrowser()
    {
       driver.quit();
    }

}
