package NopCommec;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 23/11/2016.
 */
public class Shopping_CartPage extends DriverManger{

@FindBy(xpath = "//input[@id='termsofservice']")
    private WebElement _termOfServiceButton;

    @FindBy(css = "#checkout")
private WebElement _final_checkOut_Button;

    @FindBy(css = "h2.title")
    private WebElement _billing_Address_1;


    public void user_on_Checkout() throws InterruptedException {
        Utility.cliclOnElement(_termOfServiceButton);
        Utility.cliclOnElement(_final_checkOut_Button);

        Assert.assertEquals("Billing address",Utility.getText(_billing_Address_1));

        System.out.println("your check out successfully");
    }





}
