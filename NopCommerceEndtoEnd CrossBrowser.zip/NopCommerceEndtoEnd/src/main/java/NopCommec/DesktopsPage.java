package NopCommec;

import org.bouncycastle.asn1.ua.UAObjectIdentifiers;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

/**
 * Created by User on 22/11/2016.
 */
public class DesktopsPage extends DriverManger{


    @FindBy(xpath = "//div[3]/div/div[2]/h2/a")
    private WebElement _lenova600;

    @FindBy(xpath = "//div/input[2]")
    private WebElement _addTocartButton;

    @FindBy(css = "p.content")
    private WebElement actualResult_productAdd;

    @FindBy(xpath = "//div[3]/input")
    private WebElement _clickonEmail;

    @FindBy(css = "h1")
    private WebElement _actualResult_UserOnEmailPage;

    public void elementFrom_Desktop () throws InterruptedException
    {

        Utility.explisityWait(_lenova600, 1000);
        Utility.cliclOnElement(_lenova600);
        Utility.cliclOnElement(_addTocartButton);
    }
/*        Assert.assertEquals("The product has been added to your shopping cart",Utility.getText(actualResult_productAdd));
        System.out.println("The product has been added to your shopping shopping_cartWindow");
*/

       public void clickOnEmailToFriedn()
       {
        Utility.explisityWait(_lenova600,1000);
        Utility.cliclOnElement(_lenova600);
        Utility.cliclOnElement(_clickonEmail);

           Assert.assertEquals("Email a friend",Utility.getText(_actualResult_UserOnEmailPage));
           System.out.println("User on Email A Friend");

       }

    }

