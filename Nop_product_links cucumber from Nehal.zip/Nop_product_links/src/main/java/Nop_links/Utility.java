package Nop_links;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Hello world!
 *
 */
public class Utility extends DriverManager
{

      public static void clickOnElement(WebElement element)
      {

             element.click();
      }


    public static void explisitWait(WebElement element,int timeout)
      {
        WebDriverWait wait=new WebDriverWait(driver,timeout);
        wait.until(ExpectedConditions.visibilityOf(element));
        }

     public static void getText(WebElement element)
     {
         element.getText();

     }


    }



