package Nop_links;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

import java.util.concurrent.TimeUnit;

/**
 * Created by User on 30/11/2016.
 */
public class DriverManager {

    protected static WebDriver driver;

    public DriverManager(){
        PageFactory.initElements(driver,this);
    }


    public static void openBrowser(){

     // String browser="";
      //String  browser="chrome";
       String browser="IE";

        if(browser.equalsIgnoreCase("chrome")){

            System.setProperty("webdriver.chrome.driver","src\\test\\Resource\\BrowserDriver\\chromedriver.exe");
            driver=new ChromeDriver();

        }else if(browser.equalsIgnoreCase("ie")){

            System.setProperty("webdriver.ie.driver","src\\test\\Resource\\BrowserDriver\\IEDriverServer 32.exe");
            driver=new InternetExplorerDriver();

        }
        else {
            driver=new FirefoxDriver();

        }

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("http://demo.nopcommerce.com/");



    }

  public static void closeBrowser(){
      driver.quit();
  }
}
