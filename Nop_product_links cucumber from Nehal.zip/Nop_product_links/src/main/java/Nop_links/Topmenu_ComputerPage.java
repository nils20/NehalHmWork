package Nop_links;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by User on 30/11/2016.
 */
public class Topmenu_ComputerPage extends DriverManager{


    @FindBy(linkText = "Computers")
    private WebElement _topmenu_Computer;

    @FindBy(linkText = "Electronics")
    private WebElement _topmenu_Electronics;

    @FindBy(linkText = "Apparel")
    private WebElement _topmenu_Apparel;

    @FindBy(linkText = "Digital downloads")
    private WebElement _topmenu_DigitalDownloads;

    @FindBy(linkText = "Books")
    private WebElement _topmenu_Books;

    @FindBy(linkText = "Jewelry")
    private WebElement _topmenu_Jewelry;

    @FindBy(linkText = "Gift Cards")
    private WebElement _topmenu_GiftCards;

    @FindBy(css = "css=strong.current-item")
    private WebElement _actualResultForComputer_page;

    public void clickOnComputerTab(){
        Utility.clickOnElement(_topmenu_Computer);

    }
    public void clickOnElectronicsTab(){
        Utility.clickOnElement(_topmenu_Electronics);

    }
    public void clickOnApparelTab(){
        Utility.clickOnElement(_topmenu_Apparel);

    }
    public void clickOnDigitalDownloadsTab(){
        Utility.clickOnElement(_topmenu_DigitalDownloads);

    }
    public void clickOnBooksTab(){
        Utility.clickOnElement(_topmenu_Books);

    }
    public void clickOnJewelryTab(){
        Utility.clickOnElement(_topmenu_Jewelry);

    }
    public void clickOnGiftCardsTab(){
        Utility.clickOnElement(_topmenu_GiftCards);

    }

}
