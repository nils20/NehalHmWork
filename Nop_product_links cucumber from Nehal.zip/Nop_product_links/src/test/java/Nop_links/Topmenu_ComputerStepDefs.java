package Nop_links;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.deps.com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
import org.junit.Assert;
import org.openqa.selenium.By;

/**
 * Created by User on 30/11/2016.
 */
public class Topmenu_ComputerStepDefs extends DriverManager {



    @Given("^I am on nop commerce home page$")
    public void i_am_on_nop_commerce_home_page() throws Throwable {
       openBrowser();
    }

    @When("^I click on computer produt link$")
    public void i_click_on_computer_produt_link() throws Throwable {

        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnComputerTab();

    }

    @Then("^I should able to see computer product page load  successfully$")
    public void i_should_able_to_see_computer_product_page_load_successfully() throws Throwable {

        Assert.assertEquals("Computers",driver.findElement(By.linkText("Computers")).getText());
        System.out.println("Admin On Computer Page ");
        closeBrowser();
    }

    @When("^I click on electronices  produt link$")
    public void i_click_on_electronices_produt_link()  {
        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnElectronicsTab();

    }

    @Then("^I should able to see electronices  product page load  successfully$")
    public void i_should_able_to_see_electronices_product_page_load_successfully()  {
        Assert.assertEquals("Electronics",driver.findElement(By.linkText("Electronics")).getText());
        System.out.println("Admin On Electronics Page ");
        closeBrowser();

    }

    @When("^I click on Apparle  produt link$")
    public void i_click_on_Apparle_produt_link()  {
        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnApparelTab();

    }

    @Then("^I should able to see Apparle  product page load  successfully$")
    public void i_should_able_to_see_Apparle_product_page_load_successfully()  {
        Assert.assertEquals("Apparel",driver.findElement(By.linkText("Apparel")).getText());
        System.out.println("Admin On Apparel Page ");
        closeBrowser();

    }

    @When("^I click on Digital Downloads   produt link$")
    public void i_click_on_Digital_Downloads_produt_link()  {
        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnDigitalDownloadsTab();

    }

    @Then("^I should able to see Digital Downloads   product page load  successfully$")
    public void i_should_able_to_see_Digital_Downloads_product_page_load_successfully()  {
        Assert.assertEquals("Digital downloads",driver.findElement(By.linkText("Digital downloads")).getText());
        System.out.println("Admin On Digital downloads Page ");
        closeBrowser();

    }

    @When("^I click on Books  produt link$")
    public void i_click_on_Books_produt_link() {
        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnBooksTab();

    }

    @Then("^I should able to see Books  product page load  successfully$")
    public void i_should_able_to_see_Books_product_page_load_successfully()  {
        Assert.assertEquals("Books",driver.findElement(By.linkText("Books")).getText());
        System.out.println("Admin On Books Page ");
        closeBrowser();

    }

    @When("^I click on Jewelry   produt link$")
    public void i_click_on_Jewelry_produt_link()  {
        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnJewelryTab();
    }

    @Then("^I should able to see Jewelry  product page load  successfully$")
    public void i_should_able_to_see_Jewelry_product_page_load_successfully()  {
        Assert.assertEquals("Jewelry",driver.findElement(By.linkText("Jewelry")).getText());
        System.out.println("Admin On Jewelry Page ");
        closeBrowser();
    }

    @When("^I click on Gift Card  produt link$")
    public void i_click_on_Gift_Card_produt_link()  {
        Topmenu_ComputerPage topmenu_computerPage = new Topmenu_ComputerPage();
        topmenu_computerPage.clickOnGiftCardsTab();

    }

    @Then("^I should able to see Gift Card  product page load  successfully$")
    public void i_should_able_to_see_Gift_Card_product_page_load_successfully()  {
        Assert.assertEquals("Gift Cards",driver.findElement(By.linkText("Gift Cards")).getText());
        System.out.println("Admin On Gift Cards Page ");
        closeBrowser();

    }

}
