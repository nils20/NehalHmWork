package Nop_links;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.runner.RunWith;

/**
 * Unit test for simple Utility.
 */

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\Resource\\Feature\\topmenu_nopcommerce.feature")
public class TestRun
    extends DriverManager
{

}
